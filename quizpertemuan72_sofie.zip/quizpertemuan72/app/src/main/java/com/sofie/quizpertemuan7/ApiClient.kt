package com.sofie.quizpertemuan7

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.io.OutputStreamWriter
import java.util.concurrent.Executors

object ApiClient {
    private const val BASE_URL =
        "http://10.0.2.2/login_api/"

    private val executor = Executors.newSingleThreadExecutor()

    fun post(
        endpoint: String,
        data: JSONObject,
        callback: (Boolean, String, JSONObject?) -> Unit
    ) {
        executor.execute {
            var connection: HttpURLConnection? = null

            try {
                connection = URL(BASE_URL + endpoint)
                    .openConnection() as HttpURLConnection

                connection.requestMethod = "POST"
                connection.connectTimeout = 10000
                connection.readTimeout = 10000
                connection.doOutput = true
                connection.setRequestProperty(
                    "Content-Type",
                    "application/json; charset=UTF-8"
                )

                OutputStreamWriter(
                    connection.outputStream,
                    Charsets.UTF_8
                ).use { it.write(data.toString()) }

                val status = connection.responseCode
                val stream = if (status in 200..299) {
                    connection.inputStream
                } else {
                    connection.errorStream
                }

                val body = stream?.bufferedReader()?.use {
                    it.readText()
                } ?: "{}"

                val json = JSONObject(body)
                val success = json.optBoolean("success", false)
                val message = json.optString(
                    "message",
                    "Respons tidak diketahui"
                )

                callback(success, message, json.optJSONObject("data"))

            } catch (e: Exception) {
                callback(
                    false,
                    "Gagal terhubung ke server: ${e.message}",
                    null
                )
            } finally {
                connection?.disconnect()
            }
        }
    }
}
