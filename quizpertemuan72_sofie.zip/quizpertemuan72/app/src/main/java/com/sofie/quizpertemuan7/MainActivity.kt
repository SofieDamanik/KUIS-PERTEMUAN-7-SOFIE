package com.sofie.quizpertemuan7

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val email = findViewById<EditText>(R.id.etEmail)
        val password = findViewById<EditText>(R.id.etPassword)
        val btnLogin = findViewById<Button>(R.id.btnLogin)
        val tvRegister = findViewById<TextView>(R.id.tvRegister)

        btnLogin.setOnClickListener {
            val e = email.text.toString().trim()
            val p = password.text.toString()

            if (e.isEmpty() || p.isEmpty()) {
                Toast.makeText(
                    this, "Email dan password wajib diisi",
                    Toast.LENGTH_SHORT
                ).show()
                return@setOnClickListener
            }

            btnLogin.isEnabled = false

            val data = JSONObject().apply {
                put("email", e)
                put("password", p)
            }

            ApiClient.post("login.php", data) { success, message, user ->
                runOnUiThread {
                    btnLogin.isEnabled = true

                    Toast.makeText(
                        this, message, Toast.LENGTH_SHORT
                    ).show()

                    if (success && user != null) {
                        val intent = Intent(
                            this, DashboardActivity::class.java
                        )
                        intent.putExtra(
                            "nama", user.optString("nama")
                        )
                        intent.putExtra(
                            "email", user.optString("email")
                        )
                        startActivity(intent)
                        finish()
                    }
                }
            }
        }

        tvRegister.setOnClickListener {
            startActivity(
                Intent(this, RegisterActivity::class.java)
            )
        }
    }
}
